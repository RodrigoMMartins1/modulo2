# Exercício para entrega na SEMANA 6 - referente ao conteúdo trabalhado na etapa 5 (`SEMANA05/02_TUTORIAL`)

## Descrição
Atualize seu projeto individual do currículo profissional incluindo um banco de dados com as informações e disponibilize ao menos um endpoint para recuperação de alguma das informações do banco

## Forma de entrega
- Publique a sua solução no seu Github pessoal (criado com o e-mail Inteli conforme instruído no tutorial da Semana 1)
- Na resposta ao card na Adalove, inclua o link para o seu Github