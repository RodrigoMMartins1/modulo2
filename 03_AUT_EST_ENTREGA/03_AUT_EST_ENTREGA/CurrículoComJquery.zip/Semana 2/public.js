var http = require('http');
var fs = require('fs');

const express = require('express')
const app = express()
const hostname = '127.0.0.1'
const port = 3015
app.use(express.static('public'))
app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`)
})

var server = http.createServer(function (request, response) {
    fs.readFile(__dirname + "/curriculo.html", function(err, data){
        response.end(data);
    });
});

